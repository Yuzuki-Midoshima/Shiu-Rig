Shiu Rig セットアップ
=====================

対応環境
--------
Maya 2026（Arnold / mtoa を使用）

インストール
------------
1. ZIPを任意の場所へ展開します。
2. Maya 2026を起動し、新規シーンのままにします。
3. Shiu_RIG_Distribution/Shiu_drag_drop_install.py をMayaのビューポートへドラッグ＆ドロップします。
4. 「Shiu Rig setup is complete」と表示されたら完了です。

新規シーンが未編集の場合は、Shiu_RIG.ma が自動で開き、同梱テクスチャへ再接続されます。
作業中のシーンがある場合は上書きせず、そのシーンを維持します。

使用方法
--------
インストール後のリグは、Mayaユーザーフォルダ内の次の場所にコピーされます。
modules/ShiuRig/RIG/scenes/Shiu_RIG.ma

別のShiuシーンを開いた場合も、同梱テクスチャと同名のファイルは自動再接続されます。

再インストール・更新
--------------------
新しいZIPを展開し、Shiu_drag_drop_install.py をもう一度Mayaへドロップしてください。
既存のShiuRigモジュールは自動更新されます。

注意
----
- ZIPの中身を直接実行せず、必ず先に展開してください。
- 展開後は RIG、scripts、Shiu_drag_drop_install.py の相対位置を変えないでください。
- インストーラは既存の userSetup.py を削除せず、Shiu Rig用の起動ブロックだけを追加・更新します。
