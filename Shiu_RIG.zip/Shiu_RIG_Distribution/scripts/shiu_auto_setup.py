# -*- coding: utf-8 -*-
"""Open Shiu and keep its package textures connected on future scene loads."""
from __future__ import print_function

import __main__
import os

import maya.cmds as cmds
import maya.mel as mel
import maya.utils

_SCENE_JOB_KEY = "_shiu_scene_open_job_v1"


def package_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def project_root():
    return os.path.join(package_root(), "RIG")


def scene_path():
    return os.path.join(project_root(), "scenes", "Shiu_RIG.ma")


def _is_shiu_scene():
    return cmds.objExists("Shiu_model_Re_SHIU_baseColor_FILE") or cmds.objExists(
        "shiu_RIG_body_skeleton_v2_chara_BaseColor_file"
    )


def repair_current_scene():
    if not _is_shiu_scene():
        return
    import shiu_texture_paths
    shiu_texture_paths.reconnect_textures()


def open_rig_if_clean():
    """Open the bundled rig only when Maya is still on an untouched new scene."""
    if cmds.file(query=True, sceneName=True) or cmds.file(query=True, modified=True):
        return False
    scene = scene_path()
    if not os.path.isfile(scene):
        raise RuntimeError("Bundled Shiu Rig scene was not found: " + scene)
    mel.eval('setProject "{}"'.format(project_root().replace("\\", "/").replace('"', '\\"')))
    cmds.file(scene.replace("\\", "/"), open=True, force=True, prompt=False)
    repair_current_scene()
    print("[SHIU] Opened rig scene: " + scene)
    return True


def _on_scene_opened():
    maya.utils.executeDeferred(repair_current_scene)


def start():
    previous = getattr(__main__, _SCENE_JOB_KEY, None)
    if previous is not None and cmds.scriptJob(exists=previous):
        cmds.scriptJob(kill=previous, force=True)
    job = cmds.scriptJob(event=["SceneOpened", _on_scene_opened], protected=True)
    setattr(__main__, _SCENE_JOB_KEY, job)
    maya.utils.executeDeferred(repair_current_scene)
    print("[SHIU AUTO SETUP READY] sceneJob={}".format(job))
