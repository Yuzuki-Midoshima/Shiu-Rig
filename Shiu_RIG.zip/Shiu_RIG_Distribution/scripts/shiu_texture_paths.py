# -*- coding: utf-8 -*-
"""Resolve Shiu texture nodes from the installed package."""
from __future__ import print_function

import os
import maya.cmds as cmds

TEXTURE_ATTRS = (("file", "fileTextureName"), ("aiImage", "filename"), ("imagePlane", "imageName"))


def _texture_index():
    package_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    texture_root = os.path.join(package_root, "RIG", "sourceimages")
    result = {}
    if os.path.isdir(texture_root):
        for folder, _dirs, files in os.walk(texture_root):
            for filename in files:
                result.setdefault(filename.lower(), os.path.join(folder, filename))
    return result


def reconnect_textures():
    """Reconnect matching texture basenames to this package's sourceimages."""
    index = _texture_index()
    repaired = 0
    unresolved = []
    for node_type, attr_name in TEXTURE_ATTRS:
        for node in cmds.ls(type=node_type) or []:
            plug = node + "." + attr_name
            try:
                current = cmds.getAttr(plug) or ""
                # rsplit also handles Maya project-relative paths such as
                # //sourceimages/file.png, which ntpath treats as a UNC share.
                basename = current.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1].lower()
                replacement = index.get(basename)
                if replacement:
                    portable_path = replacement.replace("\\", "/")
                    if current != portable_path:
                        cmds.setAttr(plug, portable_path, type="string")
                        repaired += 1
                elif current and not os.path.isfile(os.path.expandvars(os.path.expanduser(current))):
                    unresolved.append((node, current))
            except Exception as exc:
                cmds.warning("[SHIU] Could not inspect {}: {}".format(plug, exc))
    print("[SHIU] Portable textures connected: {}".format(repaired))
    if unresolved:
        cmds.warning("[SHIU] {} texture path(s) remain unresolved; see Script Editor.".format(len(unresolved)))
        for node, path in unresolved:
            print("[SHIU] Unresolved texture: {} -> {}".format(node, path))
    return repaired, unresolved
