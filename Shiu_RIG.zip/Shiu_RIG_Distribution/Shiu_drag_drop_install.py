# -*- coding: utf-8 -*-
"""Drag this file into a Maya viewport to install and open the Shiu rig."""
from __future__ import print_function

import codecs
import os
import shutil
import sys
import traceback

PACKAGE_NAME = "ShiuRig"
BOOT_BEGIN = "# >>> SHIU RIG AUTO SETUP >>>"
BOOT_END = "# <<< SHIU RIG AUTO SETUP <<<"
BOOT_CODE = """{0}
try:
    import shiu_auto_setup
    shiu_auto_setup.start()
except Exception:
    import traceback
    traceback.print_exc()
{1}
""".format(BOOT_BEGIN, BOOT_END)


def _copy_package(source_root, install_root):
    if os.path.isdir(install_root):
        shutil.rmtree(install_root)
    ignore = shutil.ignore_patterns(".git", ".agents", ".codex", ".aws", "__pycache__", "*.pyc", "*.zip")
    shutil.copytree(source_root, install_root, ignore=ignore)


def _write_module(module_file, install_root):
    content = "+ {0} 1.0 {1}\nPYTHONPATH +:= scripts\nMAYA_SCRIPT_PATH +:= scripts\n".format(
        PACKAGE_NAME, install_root.replace("\\", "/")
    )
    with open(module_file, "w") as stream:
        stream.write(content)


def _read_user_setup(path):
    with open(path, "rb") as stream:
        data = stream.read()
    if data.startswith(codecs.BOM_UTF8):
        return data.decode("utf-8-sig"), "utf-8-sig"
    if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
        return data.decode("utf-16"), "utf-16"
    for encoding in ("utf-8", "cp932"):
        try:
            return data.decode(encoding), encoding
        except UnicodeDecodeError:
            pass
    return data.decode("latin-1"), "latin-1"


def _update_user_setup(path):
    old = u""
    encoding = "utf-8"
    if os.path.isfile(path):
        old, encoding = _read_user_setup(path)
    if BOOT_BEGIN in old and BOOT_END in old:
        before, remainder = old.split(BOOT_BEGIN, 1)
        _discard, after = remainder.split(BOOT_END, 1)
        old = before.rstrip() + "\n" + after.lstrip("\r\n")
    updated = old.rstrip() + (u"\n\n" if old.strip() else u"") + BOOT_CODE
    with open(path, "wb") as stream:
        stream.write(updated.encode(encoding))


def install():
    import maya.cmds as cmds
    import maya.mel as mel

    source_root = os.path.dirname(os.path.abspath(__file__))
    modules_dir = os.path.join(cmds.internalVar(userAppDir=True), "modules")
    scripts_dir = cmds.internalVar(userScriptDir=True)
    install_root = os.path.join(modules_dir, PACKAGE_NAME)
    for folder in (modules_dir, scripts_dir):
        if not os.path.isdir(folder):
            os.makedirs(folder)
    try:
        _copy_package(source_root, install_root)
        _write_module(os.path.join(modules_dir, PACKAGE_NAME + ".mod"), install_root)
        _update_user_setup(os.path.join(scripts_dir, "userSetup.py"))
        installed_scripts = os.path.join(install_root, "scripts")
        if installed_scripts not in sys.path:
            sys.path.insert(0, installed_scripts)
        sys.modules.pop("shiu_auto_setup", None)
        sys.modules.pop("shiu_texture_paths", None)
        import shiu_auto_setup
        rig_opened = shiu_auto_setup.open_rig_if_clean()
        shiu_auto_setup.start()
        mel.eval("rehash")
        state = "The bundled rig scene has been opened." if rig_opened else "The current scene was kept unchanged."
        cmds.confirmDialog(
            title="Shiu Rig",
            message="Shiu Rig setup is complete.\n{}\n\nInstalled to:\n{}".format(state, install_root),
            button=["OK"],
        )
    except Exception:
        traceback.print_exc()
        cmds.confirmDialog(
            title="Shiu Rig - Install failed",
            message="Installation failed. See Script Editor for details.",
            button=["OK"], icon="critical",
        )
        raise


def onMayaDroppedPythonFile(*_args, **_kwargs):
    install()


if __name__ == "__main__":
    install()
